﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SEDC.Oop.Homeworks.Classes.Hogwarts.WizardsOfHogwarts
{
    public class Wizards
    {
        public string Name { get; set; }
        public int PowerLevel { get; set; }
        public int Age { get; set; }
       // public DateTime DateOfAdmission { get; set; }
        public bool HasGraduated { get; set; }

    public Wizards (string name, int powerLevel,  int age, bool hasGraduated)
    {
            Name = name;
            PowerLevel = powerLevel;
            Age = age;
           // DateOfAdmission = dateOfAdmission;
            HasGraduated = hasGraduated;
    }

    }



}







