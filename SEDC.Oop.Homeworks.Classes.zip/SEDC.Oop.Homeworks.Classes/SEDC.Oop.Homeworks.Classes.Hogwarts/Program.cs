﻿using SEDC.Oop.Homeworks.Classes.Hogwarts.Creatures;
using SEDC.Oop.Homeworks.Classes.Hogwarts.WizardsOfHogwarts;
using System;

namespace SEDC.Oop.Homeworks.Classes.Hogwarts
{
    internal class Program
    {
        static void Main(string[] args)
        {
            TheCreatures creature01 = new TheCreatures("Hija", 28, 4, false);
            TheCreatures creature02 = new TheCreatures("nkdd", 2332, 454, false);
            TheCreatures creature00 = new TheCreatures("shkfs", 332, 4, true);

            //Wizards wizard1 = new Wizards("Maja", 23, new DateTime(02, 04, 2010), 14, true);
            //Wizards wizard2 = new Wizards("hdasMaja", 223, new DateTime(1, 10, 2013), 124, false);
            //Wizards wizard3 = new Wizards("Majadsaf", 233, new DateTime(11, 10, 2013), 142, true);

            Wizards wizard1 = new Wizards("Maja", 23, 14, true);
            Wizards wizard2 = new Wizards("hdasMaja", 223, 124, false);
            Wizards wizard3 = new Wizards("Majadsaf", 233, 142, true);









            TheCreatures[] arrayOfCreatures =
                {
                creature00,
                creature01,
                creature02,
                new TheCreatures("fjs", 23, 2, false)
            };

            Wizards[] arrayOfWizards =
            {
                wizard1,
                wizard2,
                wizard3,
            };

            Console.WriteLine(WizardsVersusCreatures(creature01, wizard1));
            TamingCreatures(arrayOfCreatures, arrayOfWizards);



        
        
        }



        
            public static bool WizardsVersusCreatures(TheCreatures creature, Wizards wizard)
        {
            if (creature.IsTamed)
            {
                bool notification = false;
                return notification;
            }

            else if (wizard.PowerLevel >= creature.PowerLevel)
            {
                creature.IsTamed = true;
                bool victory = true;
                return victory;
            }

            else 
            {
                bool creatureWon = false;
                return creatureWon;
            }
        }


        public static int TamingCreatures(TheCreatures[] arrayOfCreatures, Wizards [] arrayOfWizard)
        {

            int maxCreatures = 0;
            int maxWizards = 0;
           

            string[] names = new string [arrayOfCreatures.Length];
            int j = 0;

            for(int i = 0; i < arrayOfCreatures.Length; i++)
            {
                if (arrayOfCreatures[i].PowerLevel > maxCreatures)
                {
                    maxCreatures = arrayOfCreatures[i].PowerLevel;
                }
               
            }

            for(int i = 0; i <arrayOfWizard.Length; i++)
            {
                if(arrayOfWizard[i].PowerLevel > maxWizards)
                {
                    
                    maxWizards = arrayOfWizard[i].PowerLevel;
                }
                
            }


            if(maxWizards > maxCreatures)
            {
                Console.WriteLine("All the creatures can be tamed");
                return 1;
            }
            else
                {
                for(int i = 0; i < arrayOfCreatures.Length; i++)
                {
                    if (maxWizards < arrayOfCreatures[i].PowerLevel)
                    names[j] =$" {j+1} {arrayOfCreatures[i].Name}";
                    j++;
                }

                string finalAnswer = "Not all creatures can be tamed! The creatures who cannot be tamed are: ";
                for(int i=0; i < names.Length; i++)
                {
                    finalAnswer += names[i];
                }

                Console.WriteLine(finalAnswer);
                return -1;
            }

        }
    }
}

